#ifndef _SINGLETON_H_
#define _SINGLETON_H_

#include <unistd.h>

void singleton(const char* name);
gboolean is_application_running(const char* path);

#endif /* end of include guard: _SINGLETON_H_ */

