What it will be?
===============
* logout/shutdown/reboot dialog
* autostart manager
* session manager
* xsettings-daemon
* DDE core component scheduler


the urgent tasks
================
* autostart support
* dialog support
