#ifndef __GLOBAL_H__
#define __GLOBAL_H__

#ifdef __DUI_DEBUG
#define PRIVATE 
#else
#define PRIVATE static
#endif

#define JS_EXPORT_API
#define DBUS_EXPORT_API

#endif
