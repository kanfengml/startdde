package main

import "./display"

func startDisplay() {
	display.Start()
}
